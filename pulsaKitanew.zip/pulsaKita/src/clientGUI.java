
import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import inc.config;
import static inc.config.conn;
import java.awt.Choice;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Dyah Ayu PS_
 */
public class clientGUI extends javax.swing.JFrame {

    Connection conn = config.Conn();;
    Statement st;
    ResultSet rs;
    /**
     * Creates new form NewJFrame
     */
    public clientGUI() {
        initComponents();
        jumlahPoint();
        jumlahSaldo();
    }
    
    private void jumlahPoint(){
        try{
        String sql = "select * from point where id_user='"+loginGUI.getId()+"'";
        st = conn.createStatement();
        rs = st.executeQuery(sql);
        rs.next();
        tpoint.setText(String.valueOf(rs.getInt("jumlah_point")));
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    private void jumlahSaldo(){
        try{
        String sql = "select * from rekening where id_user='"+loginGUI.getId()+"'";
        st = conn.createStatement();
        rs = st.executeQuery(sql);
        rs.next();
        tsaldo.setText(String.valueOf(rs.getInt("saldo_rekening")));
        tsaldo2.setText(String.valueOf(rs.getInt("saldo_rekening")));
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    private int jumPointSelected(){
    int baris = table.getSelectedRow();
    int value = Integer.parseInt(table.getModel().getValueAt(baris, 3).toString());
    return value;
    }
    private int hargaPulsaSelected(){
    int baris = table1.getSelectedRow();
    int value = Integer.parseInt(table1.getModel().getValueAt(baris, 3).toString());
    return value;
    }
    private int hargaDataSelected(){
    int baris = table3.getSelectedRow();
    int value = Integer.parseInt(table3.getModel().getValueAt(baris, 3).toString());
    return value;
    }
    private int jumPointPulsa(){
    int baris = table1.getSelectedRow();
    int value = Integer.parseInt(table1.getModel().getValueAt(baris, 4).toString());
    return value;    
    }
    private int jumPointData(){
    int baris = table3.getSelectedRow();
    int value = Integer.parseInt(table3.getModel().getValueAt(baris, 4).toString());
    return value;    
    }
    
    public static boolean panjangAngka(String angka, int panjang){
    return angka.length() == panjang;
    }
    
    void setColor(JPanel panel){
        panel.setBackground(new Color(153,0,0));
    }
    
    void resetColor(JPanel panel){
        panel.setBackground(new Color(102,0,0));
    }
    private void kembali (){
        resetColor(btn_beranda1);
        setColor(btn_beli1);
        resetColor(btn_riwayat1);
        resetColor(btn_keluarmember1);
        resetColor(btn_tukarpoint1);
        beranda1.setVisible(false);
        beli1.setVisible(true);
        tukarpoint1.setVisible(false);
        riwayat1.setVisible(false);
        belipulsa.setVisible(false);
        belidata.setVisible(false);
    }
    
    private void tampil(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("IDreward");
        model.addColumn("Reward");
        model.addColumn("Point");
        
        try{
            String sql = "select * from reward";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            
            int no =0;
            while(rs.next()){
                no++;
                model.addRow(new Object []{
                    no, rs.getString("id_reward"),rs.getString("reward"), rs.getString("point_reward")});
            }table.setModel(model);
        }catch(Exception e){
            System.out.println(e.getMessage());
            kembali();
                    
            }
    }
    
    private void tampilpulsa(){
        DefaultTableModel model1 = new DefaultTableModel();
        model1.addColumn("No");
        model1.addColumn("Nominal");
        model1.addColumn("Berlaku hingga");
        model1.addColumn("Harga");
        model1.addColumn("Point");
        
        try{
            if(panjangAngka(notelp.getText(),12)&&pilihoperator.getSelectedItem()!="Pilih Operator"){
            String sql = "select * from pulsadata where nama_provider like'%"+pilihoperator.getSelectedItem()+"%' and id_pulsadata like'%"+11+"%'";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            
            int no =0;
            while(rs.next()){
                no++;
                model1.addRow(new Object []{
                no,rs.getString("jumlah_pulsadata"),rs.getString("masa_berlaku"), rs.getString("harga_pulsadata"), rs.getString("point_pulsadata")});
            }table1.setModel(model1); 
            }else{
             JOptionPane.showMessageDialog(null, "Nomor telepon salah atau operator belum terpilih"); 
             kembali(); 
            }
            
        }catch(Exception e){
            
            System.out.println(e.getMessage());
                 
            }
    }

    private void tampildata(){
        DefaultTableModel model1 = new DefaultTableModel();
        model1.addColumn("No");
        model1.addColumn("Keterangan");
        model1.addColumn("Berlaku hingga");
        model1.addColumn("Harga");
        model1.addColumn("Point");
        
        try{
            if(panjangAngka(notelp.getText(),12)&&pilihoperator.getSelectedItem()!="Pilih Operator"){
            String sql = "select * from pulsadata where nama_provider like'%"+pilihoperator.getSelectedItem()+"%' and id_pulsadata like'%"+22+"%'";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            
            int no =0;
            while(rs.next()){
                no++;
                model1.addRow(new Object []{
                    no,rs.getString("jumlah_pulsadata"),rs.getString("masa_berlaku"), rs.getString("harga_pulsadata"), rs.getString("point_pulsadata")});
            }table3.setModel(model1);    
            }
            else{
                JOptionPane.showMessageDialog(null, "Nomor telepon salah atau operator belum terpilih");  
                kembali(); 
            }    
        }catch(Exception e){
            System.out.println(e.getMessage()); 

        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menu1 = new javax.swing.JPanel();
        btn_beranda1 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        btn_tukarpoint1 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        btn_riwayat1 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        btn_beli1 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        btn_keluarmember1 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        card1 = new javax.swing.JPanel();
        beranda1 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        riwayat1 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        tukarpoint1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        tpoint = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tcari = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btukar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        belipulsa = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        tsaldo = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        bbelipulsa = new javax.swing.JButton();
        belidata = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        table3 = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        tsaldo2 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        bbelidata = new javax.swing.JButton();
        beli1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        btn_pulsa = new javax.swing.JLabel();
        btn_data = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        notelp = new javax.swing.JTextField();
        pilihoperator = new java.awt.Choice();
        jLabel8 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        menu1.setBackground(new java.awt.Color(51, 0, 0));
        menu1.setForeground(new java.awt.Color(51, 0, 0));
        menu1.setAutoscrolls(true);

        btn_beranda1.setBackground(new java.awt.Color(153, 0, 0));
        btn_beranda1.setAutoscrolls(true);
        btn_beranda1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_beranda1MousePressed(evt);
            }
        });

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-home-24.png"))); // NOI18N

        jLabel24.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("Beranda");

        javax.swing.GroupLayout btn_beranda1Layout = new javax.swing.GroupLayout(btn_beranda1);
        btn_beranda1.setLayout(btn_beranda1Layout);
        btn_beranda1Layout.setHorizontalGroup(
            btn_beranda1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_beranda1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel24)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_beranda1Layout.setVerticalGroup(
            btn_beranda1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_beranda1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btn_beranda1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel24)
                .addGap(21, 21, 21))
        );

        btn_tukarpoint1.setBackground(new java.awt.Color(102, 0, 0));
        btn_tukarpoint1.setAutoscrolls(true);
        btn_tukarpoint1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_tukarpoint1MousePressed(evt);
            }
        });

        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-receive-cash-24.png"))); // NOI18N

        jLabel26.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Tukar Point");

        javax.swing.GroupLayout btn_tukarpoint1Layout = new javax.swing.GroupLayout(btn_tukarpoint1);
        btn_tukarpoint1.setLayout(btn_tukarpoint1Layout);
        btn_tukarpoint1Layout.setHorizontalGroup(
            btn_tukarpoint1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_tukarpoint1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26)
                .addContainerGap(103, Short.MAX_VALUE))
        );
        btn_tukarpoint1Layout.setVerticalGroup(
            btn_tukarpoint1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_tukarpoint1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btn_tukarpoint1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel26)
                .addGap(21, 21, 21))
        );

        btn_riwayat1.setBackground(new java.awt.Color(102, 0, 0));
        btn_riwayat1.setAutoscrolls(true);
        btn_riwayat1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_riwayat1MousePressed(evt);
            }
        });

        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-combo-chart-24.png"))); // NOI18N

        jLabel28.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("Riwayat");

        javax.swing.GroupLayout btn_riwayat1Layout = new javax.swing.GroupLayout(btn_riwayat1);
        btn_riwayat1.setLayout(btn_riwayat1Layout);
        btn_riwayat1Layout.setHorizontalGroup(
            btn_riwayat1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_riwayat1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel28)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btn_riwayat1Layout.setVerticalGroup(
            btn_riwayat1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_riwayat1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btn_riwayat1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel28)
                .addGap(21, 21, 21))
        );

        btn_beli1.setBackground(new java.awt.Color(102, 0, 0));
        btn_beli1.setAutoscrolls(true);
        btn_beli1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_beli1MousePressed(evt);
            }
        });

        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-cash-in-hand-32.png"))); // NOI18N

        jLabel30.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("Beli");

        javax.swing.GroupLayout btn_beli1Layout = new javax.swing.GroupLayout(btn_beli1);
        btn_beli1.setLayout(btn_beli1Layout);
        btn_beli1Layout.setHorizontalGroup(
            btn_beli1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_beli1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel30)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btn_beli1Layout.setVerticalGroup(
            btn_beli1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_beli1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btn_beli1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel30)
                .addGap(21, 21, 21))
        );

        btn_keluarmember1.setBackground(new java.awt.Color(102, 0, 0));
        btn_keluarmember1.setAutoscrolls(true);
        btn_keluarmember1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_keluarmember1MousePressed(evt);
            }
        });

        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-export-26.png"))); // NOI18N

        jLabel32.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("Keluar Member");

        javax.swing.GroupLayout btn_keluarmember1Layout = new javax.swing.GroupLayout(btn_keluarmember1);
        btn_keluarmember1.setLayout(btn_keluarmember1Layout);
        btn_keluarmember1Layout.setHorizontalGroup(
            btn_keluarmember1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_keluarmember1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel32)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btn_keluarmember1Layout.setVerticalGroup(
            btn_keluarmember1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_keluarmember1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btn_keluarmember1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel32)
                .addGap(21, 21, 21))
        );

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(204, 204, 204));
        jLabel33.setText("PulsaKita");

        javax.swing.GroupLayout menu1Layout = new javax.swing.GroupLayout(menu1);
        menu1.setLayout(menu1Layout);
        menu1Layout.setHorizontalGroup(
            menu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn_beli1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_riwayat1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(menu1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btn_tukarpoint1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(btn_beranda1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_keluarmember1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(menu1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(menu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2)
                    .addGroup(menu1Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        menu1Layout.setVerticalGroup(
            menu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menu1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel33)
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btn_beranda1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_beli1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_tukarpoint1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_riwayat1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btn_keluarmember1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        card1.setBackground(new java.awt.Color(255, 255, 255));
        card1.setLayout(new java.awt.CardLayout());

        beranda1.setBackground(new java.awt.Color(255, 0, 0));

        jPanel10.setBackground(new java.awt.Color(204, 0, 0));

        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-account-filled-50.png"))); // NOI18N

        jLabel35.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Nama Member");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 161, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 171, Short.MAX_VALUE)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 168, Short.MAX_VALUE)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(115, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout beranda1Layout = new javax.swing.GroupLayout(beranda1);
        beranda1.setLayout(beranda1Layout);
        beranda1Layout.setHorizontalGroup(
            beranda1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        beranda1Layout.setVerticalGroup(
            beranda1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        card1.add(beranda1, "card3");

        jPanel14.setBackground(new java.awt.Color(255, 51, 51));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-time-machine-50.png"))); // NOI18N

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(775, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(324, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout riwayat1Layout = new javax.swing.GroupLayout(riwayat1);
        riwayat1.setLayout(riwayat1Layout);
        riwayat1Layout.setHorizontalGroup(
            riwayat1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        riwayat1Layout.setVerticalGroup(
            riwayat1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        card1.add(riwayat1, "card5");

        jPanel15.setBackground(new java.awt.Color(204, 0, 0));

        jLabel38.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("Jumlah Point");

        jScrollPane2.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane2.setBorder(null);

        table.setBackground(new java.awt.Color(255, 204, 153));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "IDreward", "Reward", "Point"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-pokecoins-bucket-100.png"))); // NOI18N

        tpoint.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        tpoint.setForeground(new java.awt.Color(255, 204, 153));
        tpoint.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tpoint.setText("52");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tukar Point");

        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tcariKeyTyped(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Pencarian");

        btukar.setBackground(new java.awt.Color(255, 51, 51));
        btukar.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        btukar.setForeground(new java.awt.Color(255, 255, 255));
        btukar.setText("TUKAR");
        btukar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btukarMousePressed(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(255, 204, 102));
        jLabel5.setText("Silahkan pilih reward yang tersedia di dalam tabel reward,");

        jLabel6.setForeground(new java.awt.Color(255, 204, 102));
        jLabel6.setText("setelah dirasa yakin point mencukupi, silahkan tekan tombol tukar");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel3))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btukar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(tpoint, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(149, 149, 149)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(149, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel38)
                        .addGap(4, 4, 4)
                        .addComponent(tpoint)
                        .addGap(18, 18, 18)
                        .addComponent(btukar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout tukarpoint1Layout = new javax.swing.GroupLayout(tukarpoint1);
        tukarpoint1.setLayout(tukarpoint1Layout);
        tukarpoint1Layout.setHorizontalGroup(
            tukarpoint1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        tukarpoint1Layout.setVerticalGroup(
            tukarpoint1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        card1.add(tukarpoint1, "card4");

        jPanel16.setBackground(new java.awt.Color(204, 0, 0));

        jLabel45.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setText("Jumlah Saldo");

        jScrollPane3.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane3.setBorder(null);

        table1.setBackground(new java.awt.Color(255, 204, 153));
        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "IDreward", "Reward", "Point"
            }
        ));
        table1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(table1);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-pokecoins-bucket-100.png"))); // NOI18N

        tsaldo.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        tsaldo.setForeground(new java.awt.Color(255, 204, 153));
        tsaldo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tsaldo.setText("52");

        jLabel7.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Beli Pulsa");

        bbelipulsa.setBackground(new java.awt.Color(255, 51, 51));
        bbelipulsa.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        bbelipulsa.setText("BELI");
        bbelipulsa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bbelipulsaMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(bbelipulsa, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel7))
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addGap(53, 53, 53)
                            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                                .addComponent(jLabel45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(tsaldo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jLabel2)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel45)
                        .addGap(4, 4, 4)
                        .addComponent(tsaldo))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bbelipulsa)))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout belipulsaLayout = new javax.swing.GroupLayout(belipulsa);
        belipulsa.setLayout(belipulsaLayout);
        belipulsaLayout.setHorizontalGroup(
            belipulsaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        belipulsaLayout.setVerticalGroup(
            belipulsaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        card1.add(belipulsa, "card6");

        jPanel18.setBackground(new java.awt.Color(204, 0, 0));

        jLabel47.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setText("Jumlah Saldo");

        jScrollPane5.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane5.setBorder(null);

        table3.setBackground(new java.awt.Color(255, 204, 153));
        table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "IDreward", "Reward", "Point"
            }
        ));
        table3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table3MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(table3);

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-pokecoins-bucket-100.png"))); // NOI18N

        tsaldo2.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        tsaldo2.setForeground(new java.awt.Color(255, 204, 153));
        tsaldo2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tsaldo2.setText("52");

        jLabel18.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Beli Data");

        bbelidata.setBackground(new java.awt.Color(255, 51, 51));
        bbelidata.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        bbelidata.setText("BELI");
        bbelidata.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bbelidataMousePressed(evt);
            }
        });
        bbelidata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bbelidataActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(bbelidata, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel18Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel18))
                        .addGroup(jPanel18Layout.createSequentialGroup()
                            .addGap(53, 53, 53)
                            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(tsaldo2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jLabel16)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel47)
                        .addGap(4, 4, 4)
                        .addComponent(tsaldo2))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bbelidata)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout belidataLayout = new javax.swing.GroupLayout(belidata);
        belidata.setLayout(belidataLayout);
        belidataLayout.setHorizontalGroup(
            belidataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        belidataLayout.setVerticalGroup(
            belidataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        card1.add(belidata, "card7");

        jPanel4.setBackground(new java.awt.Color(204, 0, 0));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        btn_pulsa.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 24)); // NOI18N
        btn_pulsa.setForeground(new java.awt.Color(255, 255, 255));
        btn_pulsa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btn_pulsa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-signal-filled-50.png"))); // NOI18N
        btn_pulsa.setText("Pulsa");
        btn_pulsa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_pulsa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_pulsaMouseClicked(evt);
            }
        });

        btn_data.setBackground(new java.awt.Color(204, 204, 204));
        btn_data.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 24)); // NOI18N
        btn_data.setForeground(new java.awt.Color(255, 255, 255));
        btn_data.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btn_data.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-wi-fi-26.png"))); // NOI18N
        btn_data.setText("Data");
        btn_data.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_data.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_dataMouseClicked(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-shop-64.png"))); // NOI18N

        notelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notelpActionPerformed(evt);
            }
        });
        notelp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                notelpKeyTyped(evt);
            }
        });

        pilihoperator.setBackground(new java.awt.Color(0, 0, 0));
        pilihoperator.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                pilihoperatorItemStateChanged(evt);
            }
        });

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Masukkan 12 digit nomor telepon pada kolom dibawah ini: ");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addGap(201, 201, 201))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 325, Short.MAX_VALUE)
                            .addComponent(notelp)
                            .addComponent(pilihoperator, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGap(30, 30, 30)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_data, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_pulsa))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(79, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel41, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_pulsa, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(notelp, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pilihoperator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_data, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(139, 139, 139))
        );

        pilihoperator.addItem("Pilih Operator");
        pilihoperator.addItem("Telkomsel");
        pilihoperator.addItem("Indosat");
        pilihoperator.addItem("Axis");
        pilihoperator.getAccessibleContext().setAccessibleName("");

        jLabel19.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Beli Data");

        javax.swing.GroupLayout beli1Layout = new javax.swing.GroupLayout(beli1);
        beli1.setLayout(beli1Layout);
        beli1Layout.setHorizontalGroup(
            beli1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(beli1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(beli1Layout.createSequentialGroup()
                    .addGap(221, 221, 221)
                    .addComponent(jLabel19)
                    .addContainerGap(505, Short.MAX_VALUE)))
        );
        beli1Layout.setVerticalGroup(
            beli1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(beli1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(beli1Layout.createSequentialGroup()
                    .addGap(187, 187, 187)
                    .addComponent(jLabel19)
                    .addContainerGap(187, Short.MAX_VALUE)))
        );

        card1.add(beli1, "card3");

        jLabel42.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel42.setText("S1 Sistem Informasi");

        jLabel43.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel43.setText("Universitas Airlangga");

        jLabel44.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel44.setText("2017");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(card1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel44)
                            .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(card1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel42)
                .addGap(0, 0, 0)
                .addComponent(jLabel43)
                .addGap(1, 1, 1)
                .addComponent(jLabel44)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_beranda1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_beranda1MousePressed
        // TODO add your handling code here:
        setColor(btn_beranda1);
        resetColor(btn_beli1);
        resetColor(btn_riwayat1);
        resetColor(btn_keluarmember1);
        resetColor(btn_tukarpoint1);
        beranda1.setVisible(true);
        beli1.setVisible(false);
        tukarpoint1.setVisible(false);
        riwayat1.setVisible(false);
        belipulsa.setVisible(false);
        belidata.setVisible(false);
        
    }//GEN-LAST:event_btn_beranda1MousePressed

    private void btn_tukarpoint1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_tukarpoint1MousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda1);
        resetColor(btn_beli1);
        resetColor(btn_riwayat1);
        resetColor(btn_keluarmember1);
        setColor(btn_tukarpoint1);
        beranda1.setVisible(false);
        beli1.setVisible(false);
        tukarpoint1.setVisible(true);
        tampil();
        riwayat1.setVisible(false);
        belipulsa.setVisible(false);
        belidata.setVisible(false);
    }//GEN-LAST:event_btn_tukarpoint1MousePressed

    private void btn_riwayat1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_riwayat1MousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda1);
        resetColor(btn_beli1);
        setColor(btn_riwayat1);
        resetColor(btn_keluarmember1);
        resetColor(btn_tukarpoint1);
        beranda1.setVisible(false);
        beli1.setVisible(false);
        tukarpoint1.setVisible(false);
        riwayat1.setVisible(true);
        belipulsa.setVisible(false);
        belidata.setVisible(false);
    }//GEN-LAST:event_btn_riwayat1MousePressed

    private void btn_beli1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_beli1MousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda1);
        setColor(btn_beli1);
        resetColor(btn_riwayat1);
        resetColor(btn_keluarmember1);
        resetColor(btn_tukarpoint1);
        beranda1.setVisible(false);
        beli1.setVisible(true);
        tukarpoint1.setVisible(false);
        riwayat1.setVisible(false);
        belipulsa.setVisible(false);
        belidata.setVisible(false);
    }//GEN-LAST:event_btn_beli1MousePressed

    private void btn_keluarmember1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_keluarmember1MousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda1);
        resetColor(btn_beli1);
        resetColor(btn_riwayat1);
        setColor(btn_keluarmember1);
        resetColor(btn_tukarpoint1);
    }//GEN-LAST:event_btn_keluarmember1MousePressed

    private void tcariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyTyped
        // TODO add your handling code here:
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("IDreward");
        model.addColumn("Reward");
        model.addColumn("Point");

        try{
            String sql = "select * from reward where id_reward like'%"+tcari.getText()+"%' or reward like'%"+tcari.getText()+"%'or point_reward like '%"+tcari.getText()+"%'";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            int no =0;
            while(rs.next()){
                no++;
                model.addRow(new Object []{
                    no,rs.getString("id_reward"),rs.getString("reward"), rs.getString("point_reward")});
        }table.setModel(model);
        }catch(Exception e){
            System.out.println(e.getMessage());

        }
    }//GEN-LAST:event_tcariKeyTyped

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
        jumPointSelected();
    }//GEN-LAST:event_tableMouseClicked

    private void btukarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btukarMousePressed
        // TODO add your handling code here:
        try{
        if(jumPointSelected()<=Integer.parseInt(tpoint.getText())){
            int kurang = Integer.parseInt(tpoint.getText())- jumPointSelected();
            String sql = "update point set jumlah_point='"+kurang+"'where id_user ='"+loginGUI.getId()+"'";
            st = conn.createStatement();
            st.executeUpdate(sql);
            jumlahPoint();
            JOptionPane.showMessageDialog(null, "Reward berhasil didapat");
        }else{
            JOptionPane.showMessageDialog(null, "Point anda masih belum mencukupi");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Silahkan pilih reward terlebih dahulu");
        }
    }//GEN-LAST:event_btukarMousePressed

    private void table1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_table1MouseClicked

    private void bbelipulsaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bbelipulsaMousePressed
        // TODO add your handling code here:
        try{
        if(hargaPulsaSelected()<=Integer.parseInt(tsaldo.getText())){
            int kurang = Integer.parseInt(tsaldo.getText())- hargaPulsaSelected();
            String sql = "update rekening set saldo_rekening='"+kurang+"'where id_user ='"+loginGUI.getId()+"'";
            st = conn.createStatement();
            st.executeUpdate(sql);
            jumlahSaldo();
            int tambah = Integer.parseInt(tpoint.getText())+ jumPointPulsa();
            String sql1 = "update point set jumlah_point='"+tambah+"'where id_user ='"+loginGUI.getId()+"'";
            st = conn.createStatement();
            st.executeUpdate(sql1);
            jumlahPoint();
            JOptionPane.showMessageDialog(null, "Pembelian Pulsa Berhasil, Point bertambah "+jumPointPulsa());
        }else{
            JOptionPane.showMessageDialog(null, "Pembelian Gagal,Saldo tidak mencukupi");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Silahkan pilih paket pembelian");
        }
                  
    }//GEN-LAST:event_bbelipulsaMousePressed

    private void table3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_table3MouseClicked

    private void bbelidataMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bbelidataMousePressed
        // TODO add your handling code here:
        try{
        if(hargaDataSelected()<=Integer.parseInt(tsaldo2.getText())){
            int kurang = Integer.parseInt(tsaldo2.getText())- hargaDataSelected();
            String sql = "update rekening set saldo_rekening='"+kurang+"'where id_user ='"+loginGUI.getId()+"'";
            st = conn.createStatement();
            st.executeUpdate(sql);
            jumlahSaldo();
            int tambah = Integer.parseInt(tpoint.getText())+ jumPointData();
            String sql1 = "update point set jumlah_point='"+tambah+"'where id_user ='"+loginGUI.getId()+"'";
            st = conn.createStatement();
            st.executeUpdate(sql1);
            jumlahPoint();
            JOptionPane.showMessageDialog(null, "Pembelian Data Berhasil, Point bertambah "+jumPointData());
        }else{
            JOptionPane.showMessageDialog(null, "Pembelian Gagal,Saldo tidak mencukupi");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Silahkan pilih paket pembelian");
        }
    }//GEN-LAST:event_bbelidataMousePressed

    private void btn_pulsaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_pulsaMouseClicked
        // TODO add your handling code here:
        resetColor(btn_beranda1);
        setColor(btn_beli1);
        resetColor(btn_riwayat1);
        resetColor(btn_keluarmember1);
        resetColor(btn_tukarpoint1);
        beranda1.setVisible(false);
        beli1.setVisible(false);
        tukarpoint1.setVisible(false);
        riwayat1.setVisible(false);
        belipulsa.setVisible(true);
        tampilpulsa();
        belidata.setVisible(false);
    }//GEN-LAST:event_btn_pulsaMouseClicked

    private void btn_dataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_dataMouseClicked
        // TODO add your handling code here:
        resetColor(btn_beranda1);
        setColor(btn_beli1);
        resetColor(btn_riwayat1);
        resetColor(btn_keluarmember1);
        resetColor(btn_tukarpoint1);
        beranda1.setVisible(false);
        beli1.setVisible(false);
        tukarpoint1.setVisible(false);
        riwayat1.setVisible(false);
        belipulsa.setVisible(false);
        belidata.setVisible(true);
        tampildata();
    }//GEN-LAST:event_btn_dataMouseClicked

    private void bbelidataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bbelidataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bbelidataActionPerformed

    private void pilihoperatorItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_pilihoperatorItemStateChanged
        // TODO add your handling code here:
        pilihoperator.getSelectedItem();
    }//GEN-LAST:event_pilihoperatorItemStateChanged

    private void notelpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_notelpKeyTyped
        char c = evt.getKeyChar();
        if(!(Character.isDigit(c) || c==KeyEvent.VK_BACK_SPACE) || c==KeyEvent.VK_DELETE){
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_notelpKeyTyped

    private void notelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notelpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_notelpActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(clientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(clientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(clientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(clientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new clientGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bbelidata;
    private javax.swing.JButton bbelipulsa;
    private javax.swing.JPanel beli1;
    private javax.swing.JPanel belidata;
    private javax.swing.JPanel belipulsa;
    private javax.swing.JPanel beranda1;
    private javax.swing.JPanel btn_beli1;
    private javax.swing.JPanel btn_beranda1;
    private javax.swing.JLabel btn_data;
    private javax.swing.JPanel btn_keluarmember1;
    private javax.swing.JLabel btn_pulsa;
    private javax.swing.JPanel btn_riwayat1;
    private javax.swing.JPanel btn_tukarpoint1;
    private javax.swing.JButton btukar;
    private javax.swing.JPanel card1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JPanel menu1;
    private javax.swing.JTextField notelp;
    private java.awt.Choice pilihoperator;
    private javax.swing.JPanel riwayat1;
    private javax.swing.JTable table;
    private javax.swing.JTable table1;
    private javax.swing.JTable table3;
    private javax.swing.JTextField tcari;
    private javax.swing.JLabel tpoint;
    private javax.swing.JLabel tsaldo;
    private javax.swing.JLabel tsaldo2;
    private javax.swing.JPanel tukarpoint1;
    // End of variables declaration//GEN-END:variables
}
