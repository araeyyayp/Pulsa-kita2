
import inc.config;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Dyah Ayu PS_
 */
public class serverGUI extends javax.swing.JFrame {

    Connection conn = config.Conn();
    ;
    Statement st;
    ResultSet rs;
    public static int saldoserver;

    /**
     * Creates new form serverGUI
     */
    public serverGUI() {
        initComponents();
        tampilsaldo();

    }

    public void tampilsaldo() {
        try {
            String sql = "select * from rekening where id_user ='" + '1' + "'";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            rs.next();
            saldoserver = rs.getInt("saldo_rekening");
            lSaldoAdmin.setText(String.valueOf(rs.getInt("saldo_rekening")));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void bersih() {
        tid.setText("");
        treward.setText("");
        tjumpoint.setText("");
        tid.setEditable(false);
    }

    public void bersihpulsadata() {
        tidpaket.setText("");
        tidprovider.setText("");
        tnama.setText("");
        tjumlah.setText("");
        tmasa.setText("");
        tharga.setText("");
        tpoin.setText("");
    }

    public boolean maxAngka(String angka, int max) {
        return angka.length() <= max;
    }

    private void tampil() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model.addColumn("No");
        model.addColumn("IDreward");
        model.addColumn("Reward");
        model.addColumn("Point");

        try {
            String sql = "select * from reward";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            int no = 0;
            while (rs.next()) {
                no++;
                model.addRow(new Object[]{
                    no, rs.getString("id_reward"), rs.getString("reward"), rs.getString("point_reward")});
            }
            table.setModel(model);
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }

    private void tampilpulsadata() {
        DefaultTableModel model = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model.addColumn("Id Paket");
        model.addColumn("Id Provider");
        model.addColumn("Nama Provider");
        model.addColumn("Jumlah");
        model.addColumn("Masa Berlaku");
        model.addColumn("Harga");
        model.addColumn("Point");

        try {
            String sql = "select * from pulsadata";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_pulsadata"), rs.getString("id_provider"), rs.getString("nama_provider"), rs.getString("jumlah_pulsadata"), rs.getString("masa_berlaku"), rs.getString("harga_pulsadata"), rs.getString("point_pulsadata")});
            }
            table2.setModel(model);
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }

    private void tampilRiwayat() {
        DefaultTableModel model1 = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model1.addColumn("ID Trans");
        model1.addColumn("Tanggal");
        model1.addColumn("Provider");
        model1.addColumn("Pulsa/Paket");
        model1.addColumn("Nomor HP");
        model1.addColumn("Harga");
        model1.addColumn("Point");
        model1.addColumn("id paket");
        model1.addColumn("id user");

        try {
            String sql = "select * from transaksi";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            while (rs.next()) {
                model1.addRow(new Object[]{
                    rs.getString("id_transaksi"), rs.getString("tanggal_transaksi"), "", "", rs.getString("nomor_hp"), rs.getString("harga_total"), rs.getString("point_transaksi"), rs.getString("id_pulsadata"), rs.getString("id_user")});
            }

            for (int i = 0; i < model1.getRowCount(); i++) {
                String temp = "select nama_provider, jumlah_pulsadata from pulsadata where id_pulsadata like '%" + model1.getValueAt(i, 7) + "%' ";
                st = conn.createStatement();
                rs = st.executeQuery(temp);
                rs.next();

                model1.setValueAt(rs.getString("nama_provider"), i, 2);
                model1.setValueAt(rs.getString("jumlah_pulsadata"), i, 3);
            }

            jTable1.setModel(model1);
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }
    
    private void tampilmember(){
        DefaultTableModel model2 = new DefaultTableModel();
        model2.addColumn("No");
        model2.addColumn("ID");
        model2.addColumn("Nama");
        model2.addColumn("Password");
        model2.addColumn("NoRekening");
        model2.addColumn("JumlahPoint");
        
        try{
            String sql = "select * from user";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
           
            int no =0;
            while(rs.next()){
                if (rs.getString("akses").equals("client")){
                    no++;
                    model2.addRow(new Object []{
                        no, rs.getString("id_user"),rs.getString("nama_user"), rs.getString("password"), rs.getString("nomor_rekening"), rs.getString("jumlah_poin")});
                }
            }table3.setModel(model2);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void bersihmember(){
        tiduser2.setText("");
        tnamauser2.setText("");
        tpass2.setText("");
        tnorek2.setText("");
        tiduser2.setEditable(false);
    }
    
    public boolean batasNoRek(String angka, int batas){
        return angka.length() == batas;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        card2 = new javax.swing.JPanel();
        beranda = new javax.swing.JPanel();
        lLogout = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        lAdmin = new javax.swing.JLabel();
        JLabel21 = new javax.swing.JLabel();
        lWelcome = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        lSaldoAdmin = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        lPoinAdmin = new javax.swing.JLabel();
        riwayat = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        aturhadiah = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        bsimpan = new javax.swing.JButton();
        bhapus = new javax.swing.JButton();
        scrool = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        tcari = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        treward = new javax.swing.JTextField();
        tjumpoint = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        tid = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        bubah = new javax.swing.JButton();
        aturPaket = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        bsimpan1 = new javax.swing.JButton();
        scrool2 = new javax.swing.JScrollPane();
        table2 = new javax.swing.JTable();
        tcari2 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        tidprovider = new javax.swing.JTextField();
        tnama = new javax.swing.JTextField();
        tidpaket = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        bubah1 = new javax.swing.JButton();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        tjumlah = new javax.swing.JTextField();
        tpoin = new javax.swing.JTextField();
        tharga = new javax.swing.JTextField();
        bhapus1 = new javax.swing.JButton();
        tmasa = new javax.swing.JTextField();
        aturmember = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        bsimpanmember = new javax.swing.JButton();
        bhapusmember = new javax.swing.JButton();
        tcarimember = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        tnamauser2 = new javax.swing.JTextField();
        tpass2 = new javax.swing.JTextField();
        tiduser2 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        bubahmember = new javax.swing.JButton();
        jLabel47 = new javax.swing.JLabel();
        tnorek2 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        table3 = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        bresetmember = new javax.swing.JButton();
        menu = new javax.swing.JPanel();
        btn_beranda = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btn_aturpaket = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btn_riwayat = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btn_aturmember = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        btn_aturhadiah = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        card2.setLayout(new java.awt.CardLayout());

        beranda.setBackground(new java.awt.Color(255, 0, 0));

        lLogout.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lLogout.setForeground(new java.awt.Color(255, 255, 255));
        lLogout.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-export-26.png"))); // NOI18N
        lLogout.setText("Logout");
        lLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lLogoutMousePressed(evt);
            }
        });

        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-account-filled-50.png"))); // NOI18N

        lAdmin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lAdmin.setForeground(new java.awt.Color(255, 255, 255));
        lAdmin.setText("Nama Admin");

        JLabel21.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        JLabel21.setForeground(new java.awt.Color(255, 255, 255));
        JLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLabel21.setText("Anda telah memasuki Admin Section");

        lWelcome.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lWelcome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lWelcome.setText("Welcome, admin Nama Admin");

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("SALDO :");

        lSaldoAdmin.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        lSaldoAdmin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lSaldoAdmin.setText("jLabel23");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(lSaldoAdmin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lSaldoAdmin, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
        );

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("POIN :");

        lPoinAdmin.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        lPoinAdmin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lPoinAdmin.setText("jLabel23");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(lPoinAdmin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lPoinAdmin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout berandaLayout = new javax.swing.GroupLayout(beranda);
        beranda.setLayout(berandaLayout);
        berandaLayout.setHorizontalGroup(
            berandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(berandaLayout.createSequentialGroup()
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(JLabel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lWelcome, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(berandaLayout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(100, 100, 100)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(104, Short.MAX_VALUE))
        );
        berandaLayout.setVerticalGroup(
            berandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(berandaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(berandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(berandaLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(berandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(74, 74, 74)
                .addComponent(lWelcome, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                .addGap(66, 66, 66)
                .addGroup(berandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(122, Short.MAX_VALUE))
        );

        card2.add(beranda, "card5");

        jPanel2.setBackground(new java.awt.Color(204, 51, 0));

        jLabel9.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Riwayat Transaksi");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 604, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(126, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout riwayatLayout = new javax.swing.GroupLayout(riwayat);
        riwayat.setLayout(riwayatLayout);
        riwayatLayout.setHorizontalGroup(
            riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        riwayatLayout.setVerticalGroup(
            riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        card2.add(riwayat, "card5");

        aturhadiah.setBackground(new java.awt.Color(255, 102, 0));

        jLabel25.setBackground(new java.awt.Color(204, 102, 0));
        jLabel25.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Set Reward");

        jLabel26.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Reward");

        jLabel27.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Jumlah Point");

        bsimpan.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bsimpan.setForeground(new java.awt.Color(153, 51, 0));
        bsimpan.setText("Simpan");
        bsimpan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bsimpanMousePressed(evt);
            }
        });

        bhapus.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bhapus.setForeground(new java.awt.Color(153, 51, 0));
        bhapus.setText("Hapus");
        bhapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bhapusMousePressed(evt);
            }
        });

        scrool.setBackground(new java.awt.Color(255, 153, 0));

        table.setBackground(new java.awt.Color(255, 204, 153));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "IDreward", "Reward", "Point"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        scrool.setViewportView(table);

        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcariKeyReleased(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Pencarian");

        treward.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                trewardKeyTyped(evt);
            }
        });

        tjumpoint.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tjumpointKeyTyped(evt);
            }
        });

        jLabel29.setText("maximal 25 karakter");

        tid.setEditable(false);

        jLabel31.setText("maximal 5 digit");

        jLabel10.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("IDreward");

        bubah.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bubah.setForeground(new java.awt.Color(153, 51, 0));
        bubah.setText("Ubah");
        bubah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bubahMousePressed(evt);
            }
        });

        javax.swing.GroupLayout aturhadiahLayout = new javax.swing.GroupLayout(aturhadiah);
        aturhadiah.setLayout(aturhadiahLayout);
        aturhadiahLayout.setHorizontalGroup(
            aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aturhadiahLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(aturhadiahLayout.createSequentialGroup()
                        .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(aturhadiahLayout.createSequentialGroup()
                                .addComponent(bsimpan)
                                .addGap(18, 18, 18)
                                .addComponent(bubah)
                                .addGap(18, 18, 18)
                                .addComponent(bhapus))
                            .addGroup(aturhadiahLayout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel31)
                                    .addComponent(tjumpoint, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(aturhadiahLayout.createSequentialGroup()
                                .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel10))
                                .addGap(34, 34, 34)
                                .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel29)
                                    .addComponent(treward)
                                    .addComponent(tid, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(scrool, javax.swing.GroupLayout.DEFAULT_SIZE, 333, Short.MAX_VALUE))
                    .addGroup(aturhadiahLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel28)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(aturhadiahLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel25)
                    .addContainerGap(427, Short.MAX_VALUE)))
        );
        aturhadiahLayout.setVerticalGroup(
            aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturhadiahLayout.createSequentialGroup()
                .addContainerGap(198, Short.MAX_VALUE)
                .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28))
                .addGap(18, 18, 18)
                .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(aturhadiahLayout.createSequentialGroup()
                        .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(25, 25, 25)
                        .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(treward, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addComponent(jLabel29)
                        .addGap(25, 25, 25)
                        .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(tjumpoint, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addComponent(jLabel31)
                        .addGap(98, 98, 98)
                        .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bsimpan)
                            .addComponent(bubah)
                            .addComponent(bhapus)))
                    .addComponent(scrool, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(aturhadiahLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel25)
                    .addContainerGap(539, Short.MAX_VALUE)))
        );

        card2.add(aturhadiah, "card6");

        aturPaket.setBackground(new java.awt.Color(255, 102, 102));

        jLabel36.setBackground(new java.awt.Color(204, 102, 0));
        jLabel36.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Set Paket");

        jLabel37.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Id Provider");

        jLabel38.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Nama Provider");

        bsimpan1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bsimpan1.setForeground(new java.awt.Color(153, 51, 0));
        bsimpan1.setText("Simpan");
        bsimpan1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bsimpan1MousePressed(evt);
            }
        });

        scrool2.setBackground(new java.awt.Color(255, 153, 0));
        scrool2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                scrool2MouseClicked(evt);
            }
        });

        table2.setBackground(new java.awt.Color(255, 204, 153));
        table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Paket", "Id Provider", "Nama Provider", "Jumlah", "Masa Berlaku", "Harga", "Poin"
            }
        ));
        table2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table2MouseClicked(evt);
            }
        });
        scrool2.setViewportView(table2);

        tcari2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcari2KeyReleased(evt);
            }
        });

        jLabel39.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Pencarian");

        tnama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tnamaKeyTyped(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Id Paket");

        bubah1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bubah1.setForeground(new java.awt.Color(153, 51, 0));
        bubah1.setText("Ubah");
        bubah1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bubah1MousePressed(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Jumlah");

        jLabel42.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Masa Berlaku");

        jLabel43.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Harga");

        jLabel44.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("Poin");

        tjumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tjumlahKeyTyped(evt);
            }
        });

        tpoin.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tpoinPropertyChange(evt);
            }
        });
        tpoin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tpoinKeyTyped(evt);
            }
        });

        tharga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                thargaKeyTyped(evt);
            }
        });

        bhapus1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bhapus1.setForeground(new java.awt.Color(153, 51, 0));
        bhapus1.setText("Hapus");
        bhapus1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bhapus1MousePressed(evt);
            }
        });

        javax.swing.GroupLayout aturPaketLayout = new javax.swing.GroupLayout(aturPaket);
        aturPaket.setLayout(aturPaketLayout);
        aturPaketLayout.setHorizontalGroup(
            aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aturPaketLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(aturPaketLayout.createSequentialGroup()
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(aturPaketLayout.createSequentialGroup()
                                .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(aturPaketLayout.createSequentialGroup()
                                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel37)
                                            .addComponent(jLabel19)
                                            .addComponent(jLabel38))
                                        .addGap(9, 9, 9)
                                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tidprovider, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(tnama)
                                            .addComponent(tidpaket)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturPaketLayout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(bsimpan1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(bubah1)
                                        .addGap(101, 101, 101))
                                    .addGroup(aturPaketLayout.createSequentialGroup()
                                        .addComponent(jLabel41)
                                        .addGap(58, 58, 58)
                                        .addComponent(tjumlah))
                                    .addGroup(aturPaketLayout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(aturPaketLayout.createSequentialGroup()
                                                .addComponent(jLabel44)
                                                .addGap(70, 70, 70)
                                                .addComponent(tpoin))
                                            .addGroup(aturPaketLayout.createSequentialGroup()
                                                .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel42)
                                                    .addComponent(jLabel43))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(tharga)
                                                    .addComponent(tmasa))))))
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturPaketLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(bhapus1)
                                .addGap(30, 30, 30)))
                        .addComponent(scrool2, javax.swing.GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE))
                    .addGroup(aturPaketLayout.createSequentialGroup()
                        .addGap(0, 335, Short.MAX_VALUE)
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tcari2, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(aturPaketLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel36)
                    .addContainerGap(457, Short.MAX_VALUE)))
        );
        aturPaketLayout.setVerticalGroup(
            aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturPaketLayout.createSequentialGroup()
                .addContainerGap(198, Short.MAX_VALUE)
                .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tcari2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39))
                .addGap(18, 18, 18)
                .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(aturPaketLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(tidpaket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel37)
                            .addComponent(tidprovider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel38)
                            .addComponent(tnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel41)
                            .addComponent(tjumlah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(aturPaketLayout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jLabel42)
                                .addGap(14, 14, 14))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturPaketLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tmasa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tharga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel43))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tpoin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel44))
                        .addGap(15, 15, 15)
                        .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(aturPaketLayout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(bsimpan1)
                                    .addComponent(bubah1)))
                            .addComponent(bhapus1, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addComponent(scrool2, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(aturPaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(aturPaketLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel36)
                    .addContainerGap(539, Short.MAX_VALUE)))
        );

        card2.add(aturPaket, "card6");

        aturmember.setBackground(new java.awt.Color(255, 51, 51));

        jLabel35.setBackground(new java.awt.Color(204, 102, 0));
        jLabel35.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Set Member");

        jLabel40.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Nama User");

        jLabel45.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("Password");

        bsimpanmember.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bsimpanmember.setForeground(new java.awt.Color(153, 51, 0));
        bsimpanmember.setText("Simpan");
        bsimpanmember.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bsimpanmemberMousePressed(evt);
            }
        });

        bhapusmember.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bhapusmember.setForeground(new java.awt.Color(153, 51, 0));
        bhapusmember.setText("Hapus");
        bhapusmember.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bhapusmemberMousePressed(evt);
            }
        });

        tcarimember.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tcarimemberActionPerformed(evt);
            }
        });
        tcarimember.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcarimemberKeyReleased(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("Pencarian");

        tnamauser2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tnamauser2KeyTyped(evt);
            }
        });

        tpass2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tpass2KeyTyped(evt);
            }
        });

        tiduser2.setEditable(false);
        tiduser2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tiduser2ActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("ID User");

        bubahmember.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bubahmember.setForeground(new java.awt.Color(153, 51, 0));
        bubahmember.setText("Ubah");
        bubahmember.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bubahmemberMousePressed(evt);
            }
        });

        jLabel47.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("No. Rekening");

        tnorek2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tnorek2KeyTyped(evt);
            }
        });

        table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table3MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table3);

        jLabel11.setText("maksimal 25 karakter");

        jLabel17.setText("maksimal 25 karakter");

        jLabel23.setText("harus 6 karakter");

        bresetmember.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        bresetmember.setForeground(new java.awt.Color(153, 51, 0));
        bresetmember.setText("Reset");
        bresetmember.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bresetmemberMousePressed(evt);
            }
        });
        bresetmember.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bresetmemberActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout aturmemberLayout = new javax.swing.GroupLayout(aturmember);
        aturmember.setLayout(aturmemberLayout);
        aturmemberLayout.setHorizontalGroup(
            aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aturmemberLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(aturmemberLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel46)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tcarimember, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(aturmemberLayout.createSequentialGroup()
                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(aturmemberLayout.createSequentialGroup()
                                .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(aturmemberLayout.createSequentialGroup()
                                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel20)
                                            .addComponent(jLabel45)
                                            .addComponent(jLabel40))
                                        .addGap(42, 42, 42)
                                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tpass2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(tnamauser2)
                                                .addComponent(tiduser2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel11)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturmemberLayout.createSequentialGroup()
                                        .addComponent(jLabel47)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel17)
                                            .addComponent(tnorek2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel23)))
                                    .addGroup(aturmemberLayout.createSequentialGroup()
                                        .addComponent(bsimpanmember)
                                        .addGap(18, 18, 18)
                                        .addComponent(bubahmember)
                                        .addGap(22, 22, 22)
                                        .addComponent(bhapusmember)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturmemberLayout.createSequentialGroup()
                                .addComponent(bresetmember, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(63, 63, 63)))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(aturmemberLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel35)
                    .addContainerGap(418, Short.MAX_VALUE)))
        );
        aturmemberLayout.setVerticalGroup(
            aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, aturmemberLayout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tcarimember, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel46))
                .addGap(18, 18, 18)
                .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(aturmemberLayout.createSequentialGroup()
                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tiduser2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20))
                        .addGap(26, 26, 26)
                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tnamauser2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel40))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tpass2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel45))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel47)
                            .addComponent(tnorek2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel23)
                        .addGap(84, 84, 84)
                        .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bsimpanmember)
                            .addComponent(bubahmember)
                            .addComponent(bhapusmember))
                        .addGap(18, 18, 18)
                        .addComponent(bresetmember))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(aturmemberLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel35)
                    .addContainerGap(539, Short.MAX_VALUE)))
        );

        card2.add(aturmember, "card6");

        menu.setBackground(new java.awt.Color(51, 0, 0));
        menu.setForeground(new java.awt.Color(51, 0, 0));
        menu.setAutoscrolls(true);

        btn_beranda.setBackground(new java.awt.Color(153, 0, 0));
        btn_beranda.setAutoscrolls(true);
        btn_beranda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_berandaMousePressed(evt);
            }
        });

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-home-24.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Beranda");

        javax.swing.GroupLayout btn_berandaLayout = new javax.swing.GroupLayout(btn_beranda);
        btn_beranda.setLayout(btn_berandaLayout);
        btn_berandaLayout.setHorizontalGroup(
            btn_berandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_berandaLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_berandaLayout.setVerticalGroup(
            btn_berandaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_berandaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btn_berandaLayout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(21, 21, 21))
        );

        btn_aturpaket.setBackground(new java.awt.Color(102, 0, 0));
        btn_aturpaket.setAutoscrolls(true);
        btn_aturpaket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_aturpaketMousePressed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-product-26.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Atur Paket");

        javax.swing.GroupLayout btn_aturpaketLayout = new javax.swing.GroupLayout(btn_aturpaket);
        btn_aturpaket.setLayout(btn_aturpaketLayout);
        btn_aturpaketLayout.setHorizontalGroup(
            btn_aturpaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_aturpaketLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addContainerGap(134, Short.MAX_VALUE))
        );
        btn_aturpaketLayout.setVerticalGroup(
            btn_aturpaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_aturpaketLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(btn_aturpaketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(btn_aturpaketLayout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(8, 8, 8))
                    .addGroup(btn_aturpaketLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel8)))
                .addGap(24, 24, 24))
        );

        btn_riwayat.setBackground(new java.awt.Color(102, 0, 0));
        btn_riwayat.setAutoscrolls(true);
        btn_riwayat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_riwayatMousePressed(evt);
            }
        });

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-combo-chart-24.png"))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Riwayat");

        javax.swing.GroupLayout btn_riwayatLayout = new javax.swing.GroupLayout(btn_riwayat);
        btn_riwayat.setLayout(btn_riwayatLayout);
        btn_riwayatLayout.setHorizontalGroup(
            btn_riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_riwayatLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btn_riwayatLayout.setVerticalGroup(
            btn_riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_riwayatLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(97, 97, 97))
            .addGroup(btn_riwayatLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(113, 113, 113))
        );

        btn_aturmember.setBackground(new java.awt.Color(102, 0, 0));
        btn_aturmember.setAutoscrolls(true);
        btn_aturmember.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_aturmemberMousePressed(evt);
            }
        });

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-account-filled-50.png"))); // NOI18N

        jLabel13.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Atur Member");

        javax.swing.GroupLayout btn_aturmemberLayout = new javax.swing.GroupLayout(btn_aturmember);
        btn_aturmember.setLayout(btn_aturmemberLayout);
        btn_aturmemberLayout.setHorizontalGroup(
            btn_aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_aturmemberLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addContainerGap(120, Short.MAX_VALUE))
        );
        btn_aturmemberLayout.setVerticalGroup(
            btn_aturmemberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_aturmemberLayout.createSequentialGroup()
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(btn_aturmemberLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(204, 204, 204));
        jLabel18.setText("PulsaKita_Server");

        btn_aturhadiah.setBackground(new java.awt.Color(102, 0, 0));
        btn_aturhadiah.setAutoscrolls(true);
        btn_aturhadiah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_aturhadiahMousePressed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-gift-26.png"))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Atur Hadiah");

        javax.swing.GroupLayout btn_aturhadiahLayout = new javax.swing.GroupLayout(btn_aturhadiah);
        btn_aturhadiah.setLayout(btn_aturhadiahLayout);
        btn_aturhadiahLayout.setHorizontalGroup(
            btn_aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_aturhadiahLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addContainerGap(125, Short.MAX_VALUE))
        );
        btn_aturhadiahLayout.setVerticalGroup(
            btn_aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_aturhadiahLayout.createSequentialGroup()
                .addGroup(btn_aturhadiahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(btn_aturhadiahLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(btn_aturhadiahLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(21, 21, 21)))
                .addGap(176, 176, 176))
        );

        javax.swing.GroupLayout menuLayout = new javax.swing.GroupLayout(menu);
        menu.setLayout(menuLayout);
        menuLayout.setHorizontalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn_beranda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_aturpaket, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(menuLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel18)
                .addContainerGap(25, Short.MAX_VALUE))
            .addComponent(btn_aturhadiah, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_aturmember, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_riwayat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        menuLayout.setVerticalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel18)
                .addGap(66, 66, 66)
                .addComponent(btn_beranda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_aturpaket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_aturhadiah, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_riwayat, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_aturmember, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel14.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel14.setText("S1 Sistem Informasi");

        jLabel15.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel15.setText("Universitas Airlangga");

        jLabel16.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel16.setText("2017");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(card2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap())))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(331, 331, 331)
                    .addComponent(jSeparator1)
                    .addGap(331, 331, 331)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addGap(0, 0, 0)
                .addComponent(jLabel15)
                .addGap(0, 0, 0)
                .addComponent(jLabel16)
                .addGap(25, 25, 25)
                .addComponent(card2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap(12, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(340, 340, 340)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(340, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_berandaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_berandaMousePressed
        // TODO add your handling code here:
        setColor(btn_beranda);
        resetColor(btn_riwayat);
        resetColor(btn_aturhadiah);
        resetColor(btn_aturmember);
        resetColor(btn_aturpaket);
        beranda.setVisible(true);
        tampilsaldo();
        aturPaket.setVisible(false);
        aturhadiah.setVisible(false);
        riwayat.setVisible(false);
    }//GEN-LAST:event_btn_berandaMousePressed

    private void btn_aturpaketMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_aturpaketMousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda);
        resetColor(btn_riwayat);
        resetColor(btn_aturhadiah);
        resetColor(btn_aturmember);
        setColor(btn_aturpaket);
        tampilpulsadata();
        beranda.setVisible(false);
        aturPaket.setVisible(true);
        aturhadiah.setVisible(false);
        riwayat.setVisible(false);
    }//GEN-LAST:event_btn_aturpaketMousePressed

    private void btn_riwayatMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_riwayatMousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda);
        setColor(btn_riwayat);
        resetColor(btn_aturhadiah);
        resetColor(btn_aturpaket);
        resetColor(btn_aturmember);
        beranda.setVisible(false);
        aturPaket.setVisible(false);
        aturhadiah.setVisible(false);
        riwayat.setVisible(true);
        tampilRiwayat();
    }//GEN-LAST:event_btn_riwayatMousePressed

    private void btn_aturhadiahMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_aturhadiahMousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda);
        resetColor(btn_riwayat);
        resetColor(btn_aturpaket);
        resetColor(btn_aturmember);
        setColor(btn_aturhadiah);
        beranda.setVisible(false);
        aturPaket.setVisible(false);
        aturhadiah.setVisible(true);
        tampil();
        riwayat.setVisible(false);
    }//GEN-LAST:event_btn_aturhadiahMousePressed

    private void bubahMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bubahMousePressed
        // TODO add your handling code here:
        try {
            int p = JOptionPane.showConfirmDialog(null, "Yakin untuk mengubah data ?", "Ubah", JOptionPane.YES_NO_OPTION);
            if (p == 0) {
                String sql = "update reward set reward='" + treward.getText() + "',point_reward='" + tjumpoint.getText() + "'where id_reward ='" + tid.getText() + "'";
                st = conn.createStatement();
                st.executeUpdate(sql);
                bersih();
                tampil();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bubahMousePressed

    private void tjumpointKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tjumpointKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_tjumpointKeyTyped

    private void tcariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyReleased
        // TODO add your handling code here:
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("IDreward");
        model.addColumn("Reward");
        model.addColumn("Point");

        try {
            String sql = "select * from reward where id_reward like'%" + tcari.getText() + "%' or reward like'%" + tcari.getText() + "%'or point_reward like '%" + tcari.getText() + "%'";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            int no = 0;
            while (rs.next()) {
                no++;
                model.addRow(new Object[]{
                    no, rs.getString("id_reward"), rs.getString("reward"), rs.getString("point_reward")});
            }
            table.setModel(model);
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }//GEN-LAST:event_tcariKeyReleased

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
        int baris = table.getSelectedRow();
        tid.setText(table.getModel().getValueAt(baris, 1).toString());
        treward.setText(table.getModel().getValueAt(baris, 2).toString());
        tjumpoint.setText(table.getModel().getValueAt(baris, 3).toString());

    }//GEN-LAST:event_tableMouseClicked

    private void bhapusMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bhapusMousePressed
        // TODO add your handling code here:
        try {
            int p = JOptionPane.showConfirmDialog(null, "Yakin untuk menghapus data ?", "Hapus", JOptionPane.YES_NO_OPTION);
            if (p == 0) {
                String sql = "delete from reward where id_reward='" + tid.getText() + "'";
                st = conn.createStatement();
                st.executeUpdate(sql);

                bersih();
                tampil();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bhapusMousePressed

    private void bsimpanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bsimpanMousePressed
        // TODO add your handling code here:
        try {
            if (maxAngka(treward.getText(), 25)) {
                if (maxAngka(tjumpoint.getText(), 5)) {
                    String sql = "insert into reward values(NULL, '" + treward.getText() + "','" + tjumpoint.getText() + "')";
                    st = conn.createStatement();
                    st.executeUpdate(sql);
                    bersih();
                    tampil();
                } else {
                    JOptionPane.showMessageDialog(null, "Kolom Jumlah Point maximal diisi oleh 5 digit");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Kolom reward maximal diisi oleh 25 karakter");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bsimpanMousePressed

    private void trewardKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_trewardKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_trewardKeyTyped

    private void bsimpan1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bsimpan1MousePressed
        // TODO add your handling code here:
        try {
            if (tidpaket.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "KOlom Id Paket harus diisi !");

            } else if (tidprovider.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Kolom Id Provider harus diisi !");

            } else if (tnama.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Kolom Nama Provider harus diisi !");

            } else if (tjumlah.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Kolom Jumlah harus diisi !");

            } else if (tmasa.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Kolom Masa Berlaku harus diisi !");

            } else if (tharga.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Kolom Harga harus diisi !");

            } else if (tpoin.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Kolom Point harus diisi !");

            } else {
                String sql = "insert into pulsadata (id_pulsadata,id_provider,nama_provider,jumlah_pulsadata,masa_berlaku,harga_pulsadata,point_pulsadata) values('" + tidpaket.getText() + "','" + tidprovider.getText() + "','" + tnama.getText() + "','" + tjumlah.getText() + "','" + tmasa.getText() + "','" + tharga.getText() + "','" + tpoin.getText() + "')";
                st = conn.createStatement();
                st.executeUpdate(sql);
                bersihpulsadata();
                tampilpulsadata();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bsimpan1MousePressed

    private void table2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table2MouseClicked
        // TODO add your handling code here:
        int baris = table2.getSelectedRow();
        tidpaket.setText(table2.getModel().getValueAt(baris, 0).toString());
        tidprovider.setText(table2.getModel().getValueAt(baris, 1).toString());
        tnama.setText(table2.getModel().getValueAt(baris, 2).toString());
        tjumlah.setText(table2.getModel().getValueAt(baris, 3).toString());
        tmasa.setText(table2.getModel().getValueAt(baris, 4).toString());
        tharga.setText(table2.getModel().getValueAt(baris, 5).toString());
        tpoin.setText(table2.getModel().getValueAt(baris, 6).toString());
    }//GEN-LAST:event_table2MouseClicked

    private void scrool2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_scrool2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_scrool2MouseClicked

    private void tcari2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcari2KeyReleased
        // TODO add your handling code here:
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Id Paket");
        model.addColumn("Id Provider");
        model.addColumn("Nama Provider");
        model.addColumn("Jumlah");
        model.addColumn("Masa Berlaku");
        model.addColumn("Harga");
        model.addColumn("Point");

        try {
            String sql = "select * from pulsadata where id_pulsadata like'%" + tcari2.getText() + "%' or id_provider like'%" + tcari2.getText() + "%'or nama_provider like '%" + tcari2.getText() + "%'or jumlah_pulsadata like '%" + tcari2.getText() + "%'or masa_berlaku like '%" + tcari2.getText() + "%'or harga_pulsadata like '%" + tcari2.getText() + "%'or point_pulsadata like '%" + tcari2.getText() + "%'";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_pulsadata"), rs.getString("id_provider"), rs.getString("nama_provider"), rs.getString("jumlah_pulsadata"), rs.getString("masa_berlaku"), rs.getString("harga_pulsadata"), rs.getString("point_pulsadata")});
            }
            table2.setModel(model);
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }//GEN-LAST:event_tcari2KeyReleased

    private void tnamaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnamaKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tnamaKeyTyped

    private void bubah1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bubah1MousePressed
        // TODO add your handling code here:
        try {
            int p = JOptionPane.showConfirmDialog(null, "Yakin untuk mengubah data ?", "Ubah", JOptionPane.YES_NO_OPTION);
            if (p == 0) {
                String sql = "update pulsadata set id_pulsadata='" + tidpaket.getText() + "',id_provider='" + tidprovider.getText() + "', nama_provider='" + tnama.getText() + "',jumlah_pulsadata='" + tjumlah.getText() + "',masa_berlaku='" + tmasa.getText() + "',harga_pulsadata='" + tharga.getText() + "',point_pulsadata='" + tpoin.getText() + "'where id_pulsadata ='" + tidpaket.getText() + "'";
                st = conn.createStatement();
                st.executeUpdate(sql);
                bersihpulsadata();
                tampilpulsadata();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bubah1MousePressed

    private void tjumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tjumlahKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tjumlahKeyTyped

    private void tpoinPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tpoinPropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_tpoinPropertyChange

    private void tpoinKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpoinKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tpoinKeyTyped

    private void thargaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_thargaKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_thargaKeyTyped

    private void bhapus1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bhapus1MousePressed
        // TODO add your handling code here:
        try {
            int p = JOptionPane.showConfirmDialog(null, "Yakin untuk menghapus data ?", "Hapus", JOptionPane.YES_NO_OPTION);
            if (p == 0) {
                String sql = "delete from pulsadata where id_pulsadata ='" + tidpaket.getText() + "'";
                st = conn.createStatement();
                st.executeUpdate(sql);
                bersihpulsadata();
                tampilpulsadata();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bhapus1MousePressed

    private void lLogoutMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lLogoutMousePressed
        // TODO add your handling code here:
        int a = JOptionPane.showConfirmDialog(null,"Anda ingin keluar?","Logout",JOptionPane.YES_NO_OPTION);
        if (a==0){
            this.setVisible(false);
            loginGUI login = new loginGUI();
            login.show();
            JOptionPane.showMessageDialog(null,"Anda berhasil keluar");
        }
    }//GEN-LAST:event_lLogoutMousePressed

    private void btn_aturmemberMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_aturmemberMousePressed
        // TODO add your handling code here:
        resetColor(btn_beranda);
        resetColor(btn_riwayat);
        resetColor(btn_aturhadiah);
        resetColor(btn_aturpaket);
        setColor(btn_aturmember);
        beranda.setVisible(false);
        aturPaket.setVisible(false);
        aturhadiah.setVisible(false);
        riwayat.setVisible(false);
        aturmember.setVisible(true);
        tampilmember();
    }//GEN-LAST:event_btn_aturmemberMousePressed

    private void bsimpanmemberMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bsimpanmemberMousePressed
        // TODO add your handling code here:
        try{
            if(maxAngka(tnamauser2.getText(),25)){
                if(maxAngka(tpass2.getText(),25)){
                    if(batasNoRek(tnorek2.getText(),6)){

                    }else
                    JOptionPane.showMessageDialog(null, "Kolom Nomor Rekening harus diisi oleh 6 digit");;
                }else
                JOptionPane.showMessageDialog(null, "Kolom Password maksimal diisi oleh 25 karakter");
            }else
            JOptionPane.showMessageDialog(null, "Kolom Nama User maksimal diisi oleh 25 karakter");

        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bsimpanmemberMousePressed

    private void bhapusmemberMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bhapusmemberMousePressed
        // TODO add your handling code here:
        try{
            int p = JOptionPane.showConfirmDialog(null,"Yakin untuk menghapus member ?","Hapus",JOptionPane.YES_NO_OPTION);
            if(p==0){
                String sql = "delete from user where id_user='"+tiduser2.getText()+"'";
                st = conn.createStatement();
                st.executeUpdate(sql);

                String sql2 = "delete from rekening where id_user='"+tiduser2.getText()+"'";
                st = conn.createStatement();
                st.executeUpdate(sql2);

                String sql3 = "delete from point where id_user='"+tiduser2.getText()+"'";
                st = conn.createStatement();
                st.executeUpdate(sql3);

                bersihmember();
                tampilmember();
            }
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bhapusmemberMousePressed

    private void tcarimemberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tcarimemberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tcarimemberActionPerformed

    private void tcarimemberKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcarimemberKeyReleased
        // TODO add your handling code here:
        DefaultTableModel model2 = new DefaultTableModel();
        model2.addColumn("No");
        model2.addColumn("ID");
        model2.addColumn("Nama");
        model2.addColumn("Password");
        model2.addColumn("NoRekening");
        model2.addColumn("JumlahPoint");

        try{
            String sql = "select * from user where id_user like'%"+tcarimember.getText()+"%' or nama_user like'%"+tcarimember.getText()+"%'or nomor_rekening like '%"+tcarimember.getText()+"%'";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            int no =0;
            while(rs.next()){
                if (rs.getString("akses").equals("client")){
                    no++;
                    model2.addRow(new Object []{
                        no, rs.getString("id_user"),rs.getString("nama_user"), rs.getString("password"), rs.getString("nomor_rekening"), rs.getString("jumlah_poin")});
            }
        }table2.setModel(model2);
        }catch(Exception e){
            System.out.println(e.getMessage());

        }
    }//GEN-LAST:event_tcarimemberKeyReleased

    private void tnamauser2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnamauser2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tnamauser2KeyTyped

    private void tpass2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpass2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tpass2KeyTyped

    private void tiduser2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tiduser2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tiduser2ActionPerformed

    private void bubahmemberMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bubahmemberMousePressed
        // TODO add your handling code here:
        try{
            int p = JOptionPane.showConfirmDialog(null,"Yakin untuk mengubah data ?","Ubah",JOptionPane.YES_NO_OPTION);
            if(p==0){
                st.execute("set foreign_key_checks = 0");
                String sql = "update user set nama_user='"+tnamauser2.getText()+"',password='"+tpass2.getText()+",nomor_rekening='"+tnorek2.getText()+"' where id_user ='"+tiduser2.getText()+"'";
                String sql2 = "update rekening set nomor_rekening = '"+tnorek2.getText()+"' where id_user = '"+tiduser2.getText()+"'";
                st = conn.createStatement();
                st.executeUpdate(sql);
                st.executeUpdate(sql2);
                st.execute("set foreign_key_checks = 1");

                bersihmember();
                tampilmember();
            }
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_bubahmemberMousePressed

    private void tnorek2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnorek2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tnorek2KeyTyped

    private void table3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table3MouseClicked
        // TODO add your handling code here:
        int baris = table2.getSelectedRow();
        tiduser2.setText(table2.getModel().getValueAt(baris, 1).toString());
        tnamauser2.setText(table2.getModel().getValueAt(baris, 2).toString());
        tpass2.setText(table2.getModel().getValueAt(baris, 3).toString());
        tnorek2.setText(table2.getModel().getValueAt(baris, 4).toString());
    }//GEN-LAST:event_table3MouseClicked

    private void bresetmemberMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bresetmemberMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_bresetmemberMousePressed

    private void bresetmemberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bresetmemberActionPerformed
        // TODO add your handling code here:
        bersihmember();
        tampilmember();
    }//GEN-LAST:event_bresetmemberActionPerformed

    void setColor(JPanel panel) {
        panel.setBackground(new Color(153, 0, 0));
    }

    void resetColor(JPanel panel) {
        panel.setBackground(new Color(102, 0, 0));
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(serverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(serverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(serverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(serverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new serverGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLabel21;
    private javax.swing.JPanel aturPaket;
    private javax.swing.JPanel aturhadiah;
    private javax.swing.JPanel aturmember;
    private javax.swing.JPanel beranda;
    private javax.swing.JButton bhapus;
    private javax.swing.JButton bhapus1;
    private javax.swing.JButton bhapusmember;
    private javax.swing.JButton bresetmember;
    private javax.swing.JButton bsimpan;
    private javax.swing.JButton bsimpan1;
    private javax.swing.JButton bsimpanmember;
    private javax.swing.JPanel btn_aturhadiah;
    private javax.swing.JPanel btn_aturmember;
    private javax.swing.JPanel btn_aturpaket;
    private javax.swing.JPanel btn_beranda;
    private javax.swing.JPanel btn_riwayat;
    private javax.swing.JButton bubah;
    private javax.swing.JButton bubah1;
    private javax.swing.JButton bubahmember;
    private javax.swing.JPanel card2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lAdmin;
    private javax.swing.JLabel lLogout;
    private javax.swing.JLabel lPoinAdmin;
    private javax.swing.JLabel lSaldoAdmin;
    private javax.swing.JLabel lWelcome;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel riwayat;
    private javax.swing.JScrollPane scrool;
    private javax.swing.JScrollPane scrool2;
    private javax.swing.JTable table;
    private javax.swing.JTable table2;
    private javax.swing.JTable table3;
    private javax.swing.JTextField tcari;
    private javax.swing.JTextField tcari2;
    private javax.swing.JTextField tcarimember;
    private javax.swing.JTextField tharga;
    private javax.swing.JTextField tid;
    private javax.swing.JTextField tidpaket;
    private javax.swing.JTextField tidprovider;
    private javax.swing.JTextField tiduser2;
    private javax.swing.JTextField tjumlah;
    private javax.swing.JTextField tjumpoint;
    private javax.swing.JTextField tmasa;
    private javax.swing.JTextField tnama;
    private javax.swing.JTextField tnamauser2;
    private javax.swing.JTextField tnorek2;
    private javax.swing.JTextField tpass2;
    private javax.swing.JTextField tpoin;
    private javax.swing.JTextField treward;
    // End of variables declaration//GEN-END:variables
}
