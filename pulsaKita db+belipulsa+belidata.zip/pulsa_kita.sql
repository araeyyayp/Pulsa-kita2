-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2018 at 03:21 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pulsa_kita`
--

-- --------------------------------------------------------

--
-- Table structure for table `point`
--

CREATE TABLE `point` (
  `id_point` int(5) NOT NULL,
  `id_transaksi` varchar(7) NOT NULL,
  `id_user` int(5) NOT NULL,
  `jumlah_point` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `point`
--

INSERT INTO `point` (`id_point`, `id_transaksi`, `id_user`, `jumlah_point`) VALUES
(1, '', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `provider`
--

CREATE TABLE `provider` (
  `id_provider` varchar(5) NOT NULL,
  `nama_provider` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provider`
--

INSERT INTO `provider` (`id_provider`, `nama_provider`) VALUES
('101', 'Telkomsel'),
('102', 'Indosat'),
('103', 'Axis');

-- --------------------------------------------------------

--
-- Table structure for table `pulsadata`
--

CREATE TABLE `pulsadata` (
  `id_pulsadata` varchar(5) NOT NULL,
  `id_provider` varchar(5) NOT NULL,
  `nama_provider` varchar(10) NOT NULL,
  `jumlah_pulsadata` varchar(10) NOT NULL,
  `masa_berlaku` date NOT NULL,
  `harga_pulsadata` int(15) NOT NULL,
  `point_pulsadata` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pulsadata`
--

INSERT INTO `pulsadata` (`id_pulsadata`, `id_provider`, `nama_provider`, `jumlah_pulsadata`, `masa_berlaku`, `harga_pulsadata`, `point_pulsadata`) VALUES
('1101', '101', 'Telkomsel', '5000', '2018-11-30', 5500, 5),
('1102', '102', 'Indosat', '5000', '2018-11-30', 5500, 5),
('1103', '103', 'Axis', '5000', '2018-11-30', 5500, 5),
('1104', '101', 'Telkomsel', '10000', '2018-12-08', 10500, 10),
('1108', '103', 'Axis', '20000', '2019-01-18', 20500, 20),
('1110', '102', 'Indosat', '25000', '2019-01-18', 25500, 25),
('2201', '101', 'Telkomsel', '10 Gb ', '2018-12-21', 50000, 50),
('2205', '102', 'Indosat', '10 Gb ', '2018-12-28', 40000, 40),
('2209', '103', 'Axis', '20 Gb', '2018-12-28', 20000, 20),
('2210', '101', 'Telkomsel', '5 Gb', '2018-12-28', 25000, 25);

-- --------------------------------------------------------

--
-- Table structure for table `rekening`
--

CREATE TABLE `rekening` (
  `nomor_rekening` int(6) NOT NULL,
  `id_user` varchar(5) NOT NULL,
  `saldo_rekening` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rekening`
--

INSERT INTO `rekening` (`nomor_rekening`, `id_user`, `saldo_rekening`) VALUES
(222806, '1', 150000),
(282206, '2', 17490);

-- --------------------------------------------------------

--
-- Table structure for table `reward`
--

CREATE TABLE `reward` (
  `id_reward` int(5) NOT NULL,
  `reward` varchar(25) NOT NULL,
  `point_reward` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reward`
--

INSERT INTO `reward` (`id_reward`, `reward`, `point_reward`) VALUES
(1, 'sepatu', 35),
(3, 'OTG type C', 67),
(4, 'kamera', 100),
(5, 'smartphone', 500);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(5) NOT NULL,
  `id_user` varchar(5) NOT NULL,
  `id_pulsadata` varchar(5) NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `harga_total` int(7) NOT NULL,
  `point_transaksi` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(5) NOT NULL,
  `nama_user` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `nomor_rekening` int(6) NOT NULL,
  `akses` enum('server','client') NOT NULL,
  `jumlah_poin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `password`, `nomor_rekening`, `akses`, `jumlah_poin`) VALUES
(1, 'dyah ayu', 'dyah ayu', 222806, 'server', 0),
(2, 'putri', 'putri', 282206, 'client', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `point`
--
ALTER TABLE `point`
  ADD PRIMARY KEY (`id_point`),
  ADD KEY `id_transaksi` (`id_transaksi`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`id_provider`);

--
-- Indexes for table `pulsadata`
--
ALTER TABLE `pulsadata`
  ADD PRIMARY KEY (`id_pulsadata`),
  ADD KEY `id_provider` (`id_provider`);

--
-- Indexes for table `rekening`
--
ALTER TABLE `rekening`
  ADD PRIMARY KEY (`nomor_rekening`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `reward`
--
ALTER TABLE `reward`
  ADD PRIMARY KEY (`id_reward`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id` (`id_user`),
  ADD KEY `id_pulsadata` (`id_pulsadata`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `nomor_rekening` (`nomor_rekening`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `point`
--
ALTER TABLE `point`
  MODIFY `id_point` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reward`
--
ALTER TABLE `reward`
  MODIFY `id_reward` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `point`
--
ALTER TABLE `point`
  ADD CONSTRAINT `point_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`nomor_rekening`) REFERENCES `rekening` (`nomor_rekening`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
